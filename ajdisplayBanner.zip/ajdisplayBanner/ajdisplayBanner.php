<?php
/**
* 2007-2020 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author    PrestaShop SA <contact@prestashop.com>
*  @copyright 2007-2020 PrestaShop SA
*  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

if (!defined('_PS_VERSION_')) {
    exit;
}

class AjdisplayBanner extends Module
{
    protected $config_form = false;

    public function __construct()
    {
        $this->name = 'ajdisplayBanner';
        $this->tab = 'front_office_features';
        $this->version = '1.0.0';
        $this->author = 'anis ajengui';
        $this->need_instance = 1;
        $this->templateFile='module:ajdisplayBanner/views/templates/hook/displayBanner.tpl';
        /**
         * Set $this->bootstrap to true if your module is compliant with bootstrap (PrestaShop 1.6)
         */
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('display custom banner');
        $this->description = $this->l('This module allow you to display a customizable banner block in front');

        $this->ps_versions_compliancy = array('min' => '1.6', 'max' => _PS_VERSION_);
    }

    /**
     * Don't forget to create update methods if needed:
     * http://doc.prestashop.com/display/PS16/Enabling+the+Auto-Update
     */
    public function install()
    {
		include(dirname(__FILE__) . '/sql/install.php');
        return parent::install() &&
            $this->registerHook('header') &&
            $this->registerHook('backOfficeHeader') &&
            $this->registerHook('displayHeader') &&
            $this->registerHook('displayTop');
    }

    public function uninstall()
    {
		include(dirname(__FILE__) . '/sql/uninstall.php');
        return parent::uninstall();
    }

    /**
     * Load the configuration form
     */
    public function getContent()
    {
        /**
         * If values have been submitted in the form, process.
         */
        if (((bool)Tools::isSubmit('submitAjdisplayBannerModule')) == true) {
            $this->postProcess();
        }

        $this->context->smarty->assign('module_dir', $this->_path);

        return $this->renderForm();
    }

    /**
     * Create the form that will be displayed in the configuration of your module.
     */
    protected function renderForm()
    {
        $helper = new HelperForm();

        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $helper->module = $this;
        $helper->default_form_language = $this->context->language->id;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG', 0);

        $helper->identifier = $this->identifier;
        $helper->submit_action = 'submitAjdisplayBannerModule';
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false)
            .'&configure='.$this->name.'&tab_module='.$this->tab.'&module_name='.$this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');

        $helper->tpl_vars = array(
            'fields_value' => $this->getConfigFormValues(), /* Add values for your inputs */
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id,
        );

        return $helper->generateForm(array($this->getConfigForm()));
    }

    /**
     * Create the structure of your form.
     */
    protected function getConfigForm()
    {
        return array(
            'form' => array(
                'legend' => array(
                'title' => $this->l('Settings'),
                'icon' => 'icon-cogs',
                ),
                'input' => array(
                    array(
                        'type' => 'textarea',
                        'desc' => $this->l('Enter the banner message'),
                        'name' => 'AJDISPLAYBANNER_MESSAGE',
                        'label' => $this->l('Banner Message'),
                    ),
                    array(
                        'type' => 'color',
                        'desc' => $this->l('Enter the banner background color'),
                        'name' => 'AJDISPLAYBANNER_MESSAGE_BACKGROUND_COLOR',
                        'label' => $this->l('Banner Background'),
                    ),
					array(
                        'type' => 'color',
                        'desc' => $this->l('Enter the banner color'),
                        'name' => 'AJDISPLAYBANNER_MESSAGE_COLOR',
                        'label' => $this->l('Banner message color'),
                    ),
					array(
                        'type' => 'color',
                        'desc' => $this->l('Enter the banner border color'),
                        'name' => 'AJDISPLAYBANNER_MESSAGE_BORDER_COLOR',
                        'label' => $this->l('Banner Message'),
                    ),
                ),
                'submit' => array(
                    'title' => $this->l('Save'),
                ),
            ),
        );
    }

    /**
     * Set values for the inputs.
     */
    protected function getConfigFormValues()
    {
        return array(
            'AJDISPLAYBANNER_MESSAGE' => Configuration::get('AJDISPLAYBANNER_MESSAGE', null),
            'AJDISPLAYBANNER_MESSAGE_BACKGROUND_COLOR' => Configuration::get('AJDISPLAYBANNER_MESSAGE_BACKGROUND_COLOR', '#d4edda'),
            'AJDISPLAYBANNER_MESSAGE_COLOR' => Configuration::get('AJDISPLAYBANNER_MESSAGE_COLOR', '#155724'),
            'AJDISPLAYBANNER_MESSAGE_BORDER_COLOR' => Configuration::get('AJDISPLAYBANNER_MESSAGE_BORDER_COLOR', '#c3e6cb'),
        );
    }

    /**
     * Save form data.
     */
    protected function postProcess()
    {
        $form_values = $this->getConfigFormValues();

        foreach (array_keys($form_values) as $key) {
            Configuration::updateValue($key, Tools::getValue($key));
        }
    }

    /**
    * Add the CSS & JavaScript files you want to be loaded in the BO.
    */
    public function hookBackOfficeHeader()
    {
        if (Tools::getValue('module_name') == $this->name) {
            $this->context->controller->addJS($this->_path.'views/js/back.js');
            $this->context->controller->addCSS($this->_path.'views/css/back.css');
        }
    }

    /**
     * Add the CSS & JavaScript files you want to be added on the FO.
     */
    public function hookHeader()
    {
        $this->context->controller->addJS($this->_path.'/views/js/front.js');
        $this->context->controller->addCSS($this->_path.'/views/css/front.css');
    }

    public function hookDisplayTop()
    {
        if (!$this->isCached($this->templateFile, $this->getCacheId('displayBanner'))) {
            $configs = $this->getConfigFormValues();
            $this->context->smarty->assign(array(
                'message' => $configs['AJDISPLAYBANNER_MESSAGE'],
                'background' => $configs['AJDISPLAYBANNER_MESSAGE_BACKGROUND_COLOR'],
                'color' => $configs['AJDISPLAYBANNER_MESSAGE_COLOR'],
                'border' => $configs['AJDISPLAYBANNER_MESSAGE_BORDER_COLOR']
            ));
        }
        return $this->fetch($this->templateFile, $this->getCacheId('displayBanner'));
    }


	public function getWidgetVariables($hookName = null, array $configuration = [])
    {
        $configs=$this->getConfigFormValues();

        if (!empty($configs)) {
            return array(
            'message' => $configs['AJDISPLAYBANNER_MESSAGE'],
            'background' => $configs['AJDISPLAYBANNER_MESSAGE_BACKGROUND_COLOR'],
            'color' => $configs['AJDISPLAYBANNER_MESSAGE_COLOR'],
            'border' => $configs['AJDISPLAYBANNER_MESSAGE_BORDER_COLOR']
            );
        }
        return false;
    }
	 public function renderWidget($hookName = null, array $configuration = [])
    {
        if (!$this->isCached($this->templateFile, $this->getCacheId('displayBanner'))) {
            $variables = $this->getWidgetVariables($hookName, $configuration);

            if (empty($variables)) {
                return false;
            }

            $this->smarty->assign($variables);
        }

        return $this->fetch($this->templateFile, $this->getCacheId('displayBanner'));
    }
}
